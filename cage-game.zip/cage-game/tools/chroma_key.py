"""Chroma-key the painted portraits.

Run from a folder that holds conair.png, treasure.png, wicker.png, sixty.png, ghost.png, rock.png
(1600x1600 portraits on a pure #00FF00 background). Writes <name>_key.png (RGBA) plus contact.png.
Requires: pip install pillow numpy
"""
from PIL import Image, ImageDraw
import numpy as np
names=['conair','treasure','wicker','sixty','ghost','rock']
sheet=Image.new('RGB',(3*420,2*420),(60,60,60))
for i,n in enumerate(names):
    im=np.array(Image.open(n+'.png').convert('RGB')).astype(np.float32)
    r,g,b=im[...,0],im[...,1],im[...,2]
    m=np.maximum(r,b)
    d=g-m  # green dominance
    a=np.clip(1-(d-25)/60,0,1)  # d<25 opaque, d>85 transparent
    g2=np.minimum(g,m+10)  # despill
    out=np.dstack([r,g2,b,a*255]).astype(np.uint8)
    Image.fromarray(out,'RGBA').save(n+'_key.png')
    th=Image.fromarray(out,'RGBA').resize((400,400))
    bg=Image.new('RGB',(400,400),(90,90,90));bg.paste(th,(0,0),th)
    dr=ImageDraw.Draw(bg)
    for k in range(0,400,50):
        dr.line([(k,0),(k,400)],fill=(255,0,255));dr.line([(0,k),(400,k)],fill=(255,0,255))
    sheet.paste(bg,((i%3)*420+10,(i//3)*420+10))
sheet.save('contact.png')
