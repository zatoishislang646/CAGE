"""Crop, mask and embed the head sprites.

Run after chroma_key.py in the same folder. Crop boxes are in 400px preview coordinates.
Writes <name>_head.png, heads_prev.png and heads.json (base64 WebP) for embedding in index.html.
Requires: pip install pillow numpy
"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, base64, io, json
# crop boxes in 400-scale coords (x0,y0,x1,y1); ellipse mask removes shoulders
C={'conair':(55,8,335,322),'treasure':(85,22,322,318),'wicker':(40,28,335,345),'sixty':(85,38,322,332),'ghost':(40,8,400,330),'rock':(70,38,338,332)}
out={};prev=Image.new('RGB',(6*220,240),(80,80,80))
for i,(n,b) in enumerate(C.items()):
    im=Image.open(n+'_key.png'); s=4
    cr=im.crop(tuple(v*s for v in b)); w,h=cr.size
    m=Image.new('L',(w,h),0); d=ImageDraw.Draw(m)
    d.ellipse((-w*0.04,-h*0.25,w*1.04,h*1.0),fill=255)
    m=m.filter(ImageFilter.GaussianBlur(w*0.015))
    a=np.array(cr.getchannel('A')).astype(np.float32)*np.array(m).astype(np.float32)/255
    cr.putalpha(Image.fromarray(a.astype(np.uint8)))
    bb=cr.getbbox(); cr=cr.crop(bb)
    sc=360/max(cr.size); cr=cr.resize((round(cr.size[0]*sc),round(cr.size[1]*sc)),Image.LANCZOS)
    cr.save(n+'_head.png')
    buf=io.BytesIO(); cr.save(buf,'WEBP',quality=88); out[n]={'src':'data:image/webp;base64,'+base64.b64encode(buf.getvalue()).decode(),'w':cr.size[0],'h':cr.size[1]}
    t=cr.copy(); t.thumbnail((210,230)); prev.paste(t,(i*220+5,5),t)
    print(n,cr.size,len(buf.getvalue()))
json.dump(out,open('heads.json','w'));prev.save('heads_prev.png')
